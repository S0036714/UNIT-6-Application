let userName;
let password;


function setup () {
  let size = windowWidth - windowWidth/10;
  createCanvas(size, windowHeight);
  userName = localStorage.getItem("username")

}
function draw () {


}
